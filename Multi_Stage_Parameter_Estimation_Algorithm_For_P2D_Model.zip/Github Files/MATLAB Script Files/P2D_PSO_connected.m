%% Script to Run PSO Parameter Sensitivity Based Estimation discharge/charge cycle

%% Generate Valid Randomnly Generated Particles

X_particles = zeros(n_parameters,n_particles);
tol_count = tol_count_1;
Convergence_vector = zeros(1,n_particles);

for i = 1:n_particles
    
    valid = 0;

    while valid == 0

        %% Generate a randomn particle
        index_count = 1;
        index_log_count = 1;

        for k = 1:n_parameters
            %%% check if parameter is to be optimised

            if k== Index_to_optimise(index_count)
                
                %X_particles(k,:) = (parameter_boundaries(k,2)-parameter_boundaries(i,1)).*rand(1,n_particles) + parameter_boundaries(i,1);
                if k==log_parameter_indices(index_log_count)
        
                pd = makedist('Loguniform','Lower',parameter_boundaries(k,1),'Upper',parameter_boundaries(k,2));
        
                X_particles(k,i) = random(pd,1,1);
        
                index_log_count = index_log_count + 1;
        
                if index_log_count >= length(log_parameter_indices)
                    
                    index_log_count = length(log_parameter_indices);
        
                end
        
                else
                    
                    X_particles(k,i) = (parameter_boundaries(k,2)-parameter_boundaries(k,1)).*rand(1,1) + parameter_boundaries(k,1);
                
                end
                
                
                index_count = index_count + 1;
        
                if index_count >= length(Index_to_optimise)
                    
                    index_count = length(Index_to_optimise);
        
                end
        
            end



        end

        %%% eps_neg and eps_pos based on eps_neg_elec and eps_pos_elec
        X_particles(11,i) = 1 - X_particles(10,i);

        X_particles(20,i) = 1 - X_particles(19,i);

        %% check if particle is valid

        [V_cell,Flag_convergence,time_vector] = P2D_function(X_particles(:,i),N_tot,N_shell,order,param,sim_type,V_cut_off_low,V_cut_off_high,capacity_cut_off,time_step,C_rate);

        if Flag_convergence ~= 0

            V_cell = V_cell(1)*ones(1,length(time_truth_comparison_vector));
            
            time_vector = time_truth_comparison_vector;
        end

        V_cell_estimate = pchip(time_vector,V_cell,time_truth_comparison_vector);

        RMSE_V_cell_percentage = mean(abs(V_cell_estimate - V_cell_truth_comparison_vector)./V_cell_truth_comparison_vector);
    
        RMSE_V_cell_percentage_Reigon_1 = mean(abs(V_cell_estimate(Reigon_1_start:Reigon_1_end) - V_cell_truth_comparison_vector(Reigon_1_start:Reigon_1_end))./V_cell_truth_comparison_vector(Reigon_1_start:Reigon_1_end));
    
        RMSE_V_cell_percentage_Reigon_2 = mean(abs(V_cell_estimate(Reigon_2_start:Reigon_2_end) - V_cell_truth_comparison_vector(Reigon_2_start:Reigon_2_end))./V_cell_truth_comparison_vector(Reigon_2_start:Reigon_2_end));
    
        RMSE_V_cell_percentage_Reigon_3 = mean(abs(V_cell_estimate(Reigon_3_start:Reigon_3_end) - V_cell_truth_comparison_vector(Reigon_3_start:Reigon_3_end))./V_cell_truth_comparison_vector(Reigon_3_start:Reigon_3_end));
    
        RMSE_V_cell_percentage_Reigon_4 = mean(abs(V_cell_estimate(Reigon_4_start:Reigon_4_end) - V_cell_truth_comparison_vector(Reigon_4_start:Reigon_4_end))./V_cell_truth_comparison_vector(Reigon_4_start:Reigon_4_end));
    
        RMSE_V_cell_percentage_Reigon_5 = mean(abs(V_cell_estimate(Reigon_5_start:Reigon_5_end) - V_cell_truth_comparison_vector(Reigon_5_start:Reigon_5_end))./V_cell_truth_comparison_vector(Reigon_5_start:Reigon_5_end));
    
        RMSE_V_cell_percentage_Reigon_6 = mean(abs(V_cell_estimate(Reigon_6_start:Reigon_6_end) - V_cell_truth_comparison_vector(Reigon_6_start:Reigon_6_end))./V_cell_truth_comparison_vector(Reigon_6_start:Reigon_6_end));
    
        RMSE_initial_V_cell = abs(V_cell_estimate(1) - V_cell_truth_comparison_vector(1))./V_cell_truth_comparison_vector(1) ;
    
        RMSE_end_V_cell = abs(V_cell_estimate(end) - V_cell_truth_comparison_vector(end))./V_cell_truth_comparison_vector(end) ;

        X_all_errors(:,i) = [RMSE_initial_V_cell; RMSE_V_cell_percentage_Reigon_1;RMSE_V_cell_percentage_Reigon_2;RMSE_V_cell_percentage_Reigon_3; RMSE_V_cell_percentage_Reigon_4;...
        RMSE_V_cell_percentage_Reigon_5; RMSE_V_cell_percentage_Reigon_6;RMSE_V_cell_percentage; RMSE_end_V_cell];

        X_errors(1,i) =mean(X_all_errors(2:7,i));

        if and(all([lt(X_all_errors(2,i),tol_count) lt(X_all_errors(3,i),tol_count) lt(X_all_errors(4,i),tol_count) lt(X_all_errors(5,i),tol_count) lt(X_all_errors(6,i),tol_count) lt(X_all_errors(7,i),tol_count)]),eq(Flag_convergence,0))


            valid = 1;

            output_Reigon_Errors = [num2str(i),' number of particles made'];

            disp(output_Reigon_Errors);

            Convergence_vector(i) = Flag_convergence;
        end

    end


end

%% Initialisze PSO Algorithm

local_best_parameters = X_particles;
local_best_errors = X_errors;

[M, I] = min(local_best_errors);
global_best_parameters = X_particles(:,I);
global_best_error = local_best_errors(I);

%%% Display initial error distribution
output_iter_count = ['Random Particles Created, best_error = ', num2str(global_best_error), ', mean_error = ', num2str(mean(local_best_errors)),', varriance_error = ', num2str(var(local_best_errors))];
disp(output_iter_count);

[V_cell,Flag_convergence,time_vector] = P2D_function(global_best_parameters,N_tot,N_shell,order,param,sim_type,V_cut_off_low,V_cut_off_high,capacity_cut_off,time_step,C_rate);

V_cell_estimate = pchip(time_vector,V_cell,time_truth_comparison_vector);

RMSE_V_cell_percentage = mean(abs(V_cell_estimate - V_cell_truth_comparison_vector)./V_cell_truth_comparison_vector);

RMSE_V_cell_percentage_Reigon_1 = mean(abs(V_cell_estimate(Reigon_1_start:Reigon_1_end) - V_cell_truth_comparison_vector(Reigon_1_start:Reigon_1_end))./V_cell_truth_comparison_vector(Reigon_1_start:Reigon_1_end));

RMSE_V_cell_percentage_Reigon_2 = mean(abs(V_cell_estimate(Reigon_2_start:Reigon_2_end) - V_cell_truth_comparison_vector(Reigon_2_start:Reigon_2_end))./V_cell_truth_comparison_vector(Reigon_2_start:Reigon_2_end));

RMSE_V_cell_percentage_Reigon_3 = mean(abs(V_cell_estimate(Reigon_3_start:Reigon_3_end) - V_cell_truth_comparison_vector(Reigon_3_start:Reigon_3_end))./V_cell_truth_comparison_vector(Reigon_3_start:Reigon_3_end));

RMSE_V_cell_percentage_Reigon_4 = mean(abs(V_cell_estimate(Reigon_4_start:Reigon_4_end) - V_cell_truth_comparison_vector(Reigon_4_start:Reigon_4_end))./V_cell_truth_comparison_vector(Reigon_4_start:Reigon_4_end));

RMSE_V_cell_percentage_Reigon_5 = mean(abs(V_cell_estimate(Reigon_5_start:Reigon_5_end) - V_cell_truth_comparison_vector(Reigon_5_start:Reigon_5_end))./V_cell_truth_comparison_vector(Reigon_5_start:Reigon_5_end));

RMSE_V_cell_percentage_Reigon_6 = mean(abs(V_cell_estimate(Reigon_6_start:Reigon_6_end) - V_cell_truth_comparison_vector(Reigon_6_start:Reigon_6_end))./V_cell_truth_comparison_vector(Reigon_6_start:Reigon_6_end));

output_Reigon_Errors = ['Best Particle Errors: Reigon 1 Error = ',num2str(RMSE_V_cell_percentage_Reigon_1),', Reigon 2 Error = ',num2str(RMSE_V_cell_percentage_Reigon_2), ', Reigon 3 Error = ',num2str(RMSE_V_cell_percentage_Reigon_3)...
           ', Reigon 4 Error = ',num2str(RMSE_V_cell_percentage_Reigon_4), ', Reigon 5 Error = ',num2str(RMSE_V_cell_percentage_Reigon_5),', Reigon 6 Error = ',num2str(RMSE_V_cell_percentage_Reigon_6), ', Mean Error = ', num2str(global_best_error)];

disp(output_Reigon_Errors);

%% Initialise Main PSO Loop

tol_count = tol_count_2;
tol = 0.17e-2;
err = 10;
V_particles = zeros(n_parameters,n_particles);

global_best_error_vector = zeros(1,iter_max);
global_best_error_vector(1) = global_best_error;

stop_con =0;
X_particles_output = zeros(n_parameters,n_operating_sets);
X_particles_positions = zeros(1,n_operating_sets);
output_sets = 0;
flip = 1;


%% Main PSO Loop

while output_sets ~= n_operating_sets

    %% Display iteration count
    output_iter_count = [num2str(iter), ' number of iterations completed, best_error = ', num2str(global_best_error), ', mean_error = ', num2str(mean(local_best_errors)),', varriance_error = ', num2str(var(local_best_errors))];
    disp(output_iter_count);

    %%% Apply PSO Algorithm
    V_particles = w*V_particles + c1*diag(rand(n_parameters,1))*(local_best_parameters - X_particles) + c2*diag(rand(n_parameters,1))*(global_best_parameters - X_particles);
    
    %%% Find next particle position
    X_particles = X_particles + V_particles;

    %%% eps_neg and eps_pos based on eps_neg_elec and eps_pos_elec
    X_particles(11,:) = 1 - X_particles(10,:);

    X_particles(20,:) = 1 - X_particles(19,:);

    %%% Calculate errors for new particles
    X_errors = zeros(1,n_particles);
    X_all_errors = zeros(9,n_particles);

    %% Calculate Particle Errors

    for i = 1:n_particles

        [V_cell,Flag_convergence,time_vector] = P2D_function(X_particles(:,i),N_tot,N_shell,order,param,sim_type,V_cut_off_low,V_cut_off_high,capacity_cut_off,time_step,C_rate);

        if Flag_convergence ~= 0

            V_cell = V_cell(1)*ones(1,length(time_truth_comparison_vector));
            
            time_vector = time_truth_comparison_vector;
        end

        V_cell_estimate = pchip(time_vector,V_cell,time_truth_comparison_vector);

        RMSE_V_cell_percentage = mean(abs(V_cell_estimate - V_cell_truth_comparison_vector)./V_cell_truth_comparison_vector);
    
        RMSE_V_cell_percentage_Reigon_1 = mean(abs(V_cell_estimate(Reigon_1_start:Reigon_1_end) - V_cell_truth_comparison_vector(Reigon_1_start:Reigon_1_end))./V_cell_truth_comparison_vector(Reigon_1_start:Reigon_1_end));
    
        RMSE_V_cell_percentage_Reigon_2 = mean(abs(V_cell_estimate(Reigon_2_start:Reigon_2_end) - V_cell_truth_comparison_vector(Reigon_2_start:Reigon_2_end))./V_cell_truth_comparison_vector(Reigon_2_start:Reigon_2_end));
    
        RMSE_V_cell_percentage_Reigon_3 = mean(abs(V_cell_estimate(Reigon_3_start:Reigon_3_end) - V_cell_truth_comparison_vector(Reigon_3_start:Reigon_3_end))./V_cell_truth_comparison_vector(Reigon_3_start:Reigon_3_end));
    
        RMSE_V_cell_percentage_Reigon_4 = mean(abs(V_cell_estimate(Reigon_4_start:Reigon_4_end) - V_cell_truth_comparison_vector(Reigon_4_start:Reigon_4_end))./V_cell_truth_comparison_vector(Reigon_4_start:Reigon_4_end));
    
        RMSE_V_cell_percentage_Reigon_5 = mean(abs(V_cell_estimate(Reigon_5_start:Reigon_5_end) - V_cell_truth_comparison_vector(Reigon_5_start:Reigon_5_end))./V_cell_truth_comparison_vector(Reigon_5_start:Reigon_5_end));
    
        RMSE_V_cell_percentage_Reigon_6 = mean(abs(V_cell_estimate(Reigon_6_start:Reigon_6_end) - V_cell_truth_comparison_vector(Reigon_6_start:Reigon_6_end))./V_cell_truth_comparison_vector(Reigon_6_start:Reigon_6_end));
    
        RMSE_initial_V_cell = abs(V_cell_estimate(1) - V_cell_truth_comparison_vector(1))./V_cell_truth_comparison_vector(1) ;
    
        RMSE_end_V_cell = abs(V_cell_estimate(end) - V_cell_truth_comparison_vector(end))./V_cell_truth_comparison_vector(end) ;

        X_all_errors(:,i) = [RMSE_initial_V_cell; RMSE_V_cell_percentage_Reigon_1;RMSE_V_cell_percentage_Reigon_2;RMSE_V_cell_percentage_Reigon_3; RMSE_V_cell_percentage_Reigon_4;...
        RMSE_V_cell_percentage_Reigon_5; RMSE_V_cell_percentage_Reigon_6;RMSE_V_cell_percentage; RMSE_end_V_cell];

        X_errors(1,i) =mean(X_all_errors(2:7,i));

       


    end

    

    %%% Update local best positions

    local_best_parameters = X_particles*diag(lt(X_errors,local_best_errors)) + local_best_parameters*diag(gt(X_errors,local_best_errors)) + local_best_parameters*diag(eq(X_errors,local_best_errors));

    local_best_errors =  X_errors*diag(lt(X_errors,local_best_errors))+ local_best_errors*diag(gt(X_errors,local_best_errors)) + local_best_errors*diag(eq(X_errors,local_best_errors)); % Might be better to calculate values manually
    

    %%% Check to see number of valid particles

    stop_check = sum(lt(local_best_errors,tol_count));

    if stop_check>0
        
        output_sets = stop_check;

        output_Reigon_Errors = ['Number of Output Parameter Sets = ',num2str(stop_check)];
        
        disp(output_Reigon_Errors);
        
        %%% Condition for stoping PSO

        if stop_check >= n_operating_sets

            stop_con = 1;

        end

    end

    


    if stop_con == 1

        break;
    end

    %Update Global Errors

    [M, I] = min(local_best_errors);

    global_best_parameters = local_best_parameters(:,I);


    %%% check if global best error changes
    if local_best_errors(I) < global_best_error

        [V_cell,Flag_convergence,time_vector] = P2D_function(global_best_parameters,N_tot,N_shell,order,param,sim_type,V_cut_off_low,V_cut_off_high,capacity_cut_off,time_step,C_rate);

        V_cell_estimate = pchip(time_vector,V_cell,time_truth_comparison_vector);

        RMSE_V_cell_percentage = mean(abs(V_cell_estimate - V_cell_truth_comparison_vector)./V_cell_truth_comparison_vector);
    
        RMSE_V_cell_percentage_Reigon_1 = mean(abs(V_cell_estimate(Reigon_1_start:Reigon_1_end) - V_cell_truth_comparison_vector(Reigon_1_start:Reigon_1_end))./V_cell_truth_comparison_vector(Reigon_1_start:Reigon_1_end));
    
        RMSE_V_cell_percentage_Reigon_2 = mean(abs(V_cell_estimate(Reigon_2_start:Reigon_2_end) - V_cell_truth_comparison_vector(Reigon_2_start:Reigon_2_end))./V_cell_truth_comparison_vector(Reigon_2_start:Reigon_2_end));
    
        RMSE_V_cell_percentage_Reigon_3 = mean(abs(V_cell_estimate(Reigon_3_start:Reigon_3_end) - V_cell_truth_comparison_vector(Reigon_3_start:Reigon_3_end))./V_cell_truth_comparison_vector(Reigon_3_start:Reigon_3_end));
    
        RMSE_V_cell_percentage_Reigon_4 = mean(abs(V_cell_estimate(Reigon_4_start:Reigon_4_end) - V_cell_truth_comparison_vector(Reigon_4_start:Reigon_4_end))./V_cell_truth_comparison_vector(Reigon_4_start:Reigon_4_end));
    
        RMSE_V_cell_percentage_Reigon_5 = mean(abs(V_cell_estimate(Reigon_5_start:Reigon_5_end) - V_cell_truth_comparison_vector(Reigon_5_start:Reigon_5_end))./V_cell_truth_comparison_vector(Reigon_5_start:Reigon_5_end));
    
        RMSE_V_cell_percentage_Reigon_6 = mean(abs(V_cell_estimate(Reigon_6_start:Reigon_6_end) - V_cell_truth_comparison_vector(Reigon_6_start:Reigon_6_end))./V_cell_truth_comparison_vector(Reigon_6_start:Reigon_6_end));
    
        RMSE_initial_V_cell = abs(V_cell_estimate(1) - V_cell_truth_comparison_vector(1))./V_cell_truth_comparison_vector(1) ;
    
        RMSE_end_V_cell = abs(V_cell_estimate(end) - V_cell_truth_comparison_vector(end))./V_cell_truth_comparison_vector(end) ;

        X_all_errors(:,i) = [RMSE_initial_V_cell; RMSE_V_cell_percentage_Reigon_1;RMSE_V_cell_percentage_Reigon_2;RMSE_V_cell_percentage_Reigon_3; RMSE_V_cell_percentage_Reigon_4;...
        RMSE_V_cell_percentage_Reigon_5; RMSE_V_cell_percentage_Reigon_6;RMSE_V_cell_percentage; RMSE_end_V_cell];

        X_errors(1,i) =mean(X_all_errors(2:7,i));

        output_Reigon_Errors = ['Reigon 1 Error = ',num2str(RMSE_V_cell_percentage_Reigon_1),', Reigon 2 Error = ',num2str(RMSE_V_cell_percentage_Reigon_2), ', Reigon 3 Error = ',num2str(RMSE_V_cell_percentage_Reigon_3)...
           ', Reigon 4 Error = ',num2str(RMSE_V_cell_percentage_Reigon_4), ', Reigon 5 Error = ',num2str(RMSE_V_cell_percentage_Reigon_5),', Reigon 6 Error = ',num2str(RMSE_V_cell_percentage_Reigon_6), ', Mean Error = ', num2str(global_best_error)];
        disp(output_Reigon_Errors);

    end


    global_best_error = local_best_errors(I);

    err = global_best_error;

    iter = iter+1;

    % Store global best error change with time
    global_best_error_vector(iter) = err;






end

%% Check if output conditions are met



if output_sets >= n_operating_sets

    idx_temp = find(lt(local_best_errors,tol_count));

    X_particles_output = local_best_parameters(:,idx_temp(1:n_operating_sets));

end


%% Output Data of Final Parameter Sets

disp('PSO Stage Complete, Final Results: ');

for k = 1:n_operating_sets

    [V_cell,Flag_convergence,time_vector] = P2D_function(X_particles_output(:,k),N_tot,N_shell,order,param,sim_type,V_cut_off_low,V_cut_off_high,capacity_cut_off,time_step,C_rate);


    V_cell_estimate = pchip(time_vector,V_cell,time_truth_comparison_vector);
    
    RMSE_V_cell_percentage = mean(abs(V_cell_estimate - V_cell_truth_comparison_vector)./V_cell_truth_comparison_vector);
    
    RMSE_V_cell_percentage_Reigon_1 = mean(abs(V_cell_estimate(Reigon_1_start:Reigon_1_end) - V_cell_truth_comparison_vector(Reigon_1_start:Reigon_1_end))./V_cell_truth_comparison_vector(Reigon_1_start:Reigon_1_end));
    
    RMSE_V_cell_percentage_Reigon_2 = mean(abs(V_cell_estimate(Reigon_2_start:Reigon_2_end) - V_cell_truth_comparison_vector(Reigon_2_start:Reigon_2_end))./V_cell_truth_comparison_vector(Reigon_2_start:Reigon_2_end));
    
    RMSE_V_cell_percentage_Reigon_3 = mean(abs(V_cell_estimate(Reigon_3_start:Reigon_3_end) - V_cell_truth_comparison_vector(Reigon_3_start:Reigon_3_end))./V_cell_truth_comparison_vector(Reigon_3_start:Reigon_3_end));
    
    RMSE_V_cell_percentage_Reigon_4 = mean(abs(V_cell_estimate(Reigon_4_start:Reigon_4_end) - V_cell_truth_comparison_vector(Reigon_4_start:Reigon_4_end))./V_cell_truth_comparison_vector(Reigon_4_start:Reigon_4_end));
    
    RMSE_V_cell_percentage_Reigon_5 = mean(abs(V_cell_estimate(Reigon_5_start:Reigon_5_end) - V_cell_truth_comparison_vector(Reigon_5_start:Reigon_5_end))./V_cell_truth_comparison_vector(Reigon_5_start:Reigon_5_end));
    
    RMSE_V_cell_percentage_Reigon_6 = mean(abs(V_cell_estimate(Reigon_6_start:Reigon_6_end) - V_cell_truth_comparison_vector(Reigon_6_start:Reigon_6_end))./V_cell_truth_comparison_vector(Reigon_6_start:Reigon_6_end));
    
    RMSE_initial_V_cell = abs(V_cell_estimate(1) - V_cell_truth_comparison_vector(1))./V_cell_truth_comparison_vector(1) ;
    
    RMSE_end_V_cell = abs(V_cell_estimate(end) - V_cell_truth_comparison_vector(end))./V_cell_truth_comparison_vector(end) ;

    X_all_errors_output = [RMSE_initial_V_cell; RMSE_V_cell_percentage_Reigon_1;RMSE_V_cell_percentage_Reigon_2;RMSE_V_cell_percentage_Reigon_3; RMSE_V_cell_percentage_Reigon_4;...
                RMSE_V_cell_percentage_Reigon_5; RMSE_V_cell_percentage_Reigon_6;RMSE_V_cell_percentage; RMSE_end_V_cell];
        
    X_errors_output =mean(X_all_errors_output(2:7));
    
    output_Reigon_Errors = [num2str(k),' Output Set Data;','Reigon 1 Error = ',num2str(RMSE_V_cell_percentage_Reigon_1),', Reigon 2 Error = ',num2str(RMSE_V_cell_percentage_Reigon_2), ', Reigon 3 Error = ',num2str(RMSE_V_cell_percentage_Reigon_3)...
               ', Reigon 4 Error = ',num2str(RMSE_V_cell_percentage_Reigon_4), ', Reigon 5 Error = ',num2str(RMSE_V_cell_percentage_Reigon_5),', Reigon 6 Error = ',num2str(RMSE_V_cell_percentage_Reigon_6), ', Mean Error = ', num2str(X_errors_output)];
    disp(output_Reigon_Errors);
    
    



end

%% Output Valid Parameter Sets From PSO Stage

writematrix([X_particles_output],'Stage_1_connected_output_sets.txt','Delimiter',' ');