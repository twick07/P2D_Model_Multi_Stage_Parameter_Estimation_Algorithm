function [Output_parameter_set, X_all_errors_output, X_errors_output] = P2D_Simulated_Annealing(initial_parameter_set,V_cell_truth_comparison_vector,Reigon_indexes,tol_count,tol_lim,time_truth_comparison_vector, delta_p,iter_max,err_con,comparison_points,N_tot,N_shell,order,param,sim_type,V_cut_off_low,V_cut_off_high,capacity_cut_off,time_step,C_rate)
    
    %% Define Reigons

    Reigon_1_start = Reigon_indexes(1);
    Reigon_1_end =  Reigon_indexes(2);
    Reigon_2_start = Reigon_indexes(3);
    Reigon_2_end =  Reigon_indexes(4);
    Reigon_3_start = Reigon_indexes(5);
    Reigon_3_end =  Reigon_indexes(6);
    Reigon_4_start = Reigon_indexes(7);
    Reigon_4_end =  Reigon_indexes(8);
    Reigon_5_start = Reigon_indexes(9);
    Reigon_5_end =  Reigon_indexes(10);
    Reigon_6_start = Reigon_indexes(11);
    Reigon_6_end =  Reigon_indexes(12);
    %% Calculate Initial Errors

    [V_cell,Flag_convergence,time_vector] = P2D_function(initial_parameter_set,N_tot,N_shell,order,param,sim_type,V_cut_off_low,V_cut_off_high,capacity_cut_off,time_step,C_rate);

    V_cell_estimate = pchip(time_vector,V_cell,time_truth_comparison_vector);

    RMSE_V_cell_percentage = mean(abs(V_cell_estimate - V_cell_truth_comparison_vector)./V_cell_truth_comparison_vector);

    RMSE_V_cell_percentage_Reigon_1 = mean(abs(V_cell_estimate(Reigon_1_start:Reigon_1_end) - V_cell_truth_comparison_vector(Reigon_1_start:Reigon_1_end))./V_cell_truth_comparison_vector(Reigon_1_start:Reigon_1_end));

    RMSE_V_cell_percentage_Reigon_2 = mean(abs(V_cell_estimate(Reigon_2_start:Reigon_2_end) - V_cell_truth_comparison_vector(Reigon_2_start:Reigon_2_end))./V_cell_truth_comparison_vector(Reigon_2_start:Reigon_2_end));

    RMSE_V_cell_percentage_Reigon_3 = mean(abs(V_cell_estimate(Reigon_3_start:Reigon_3_end) - V_cell_truth_comparison_vector(Reigon_3_start:Reigon_3_end))./V_cell_truth_comparison_vector(Reigon_3_start:Reigon_3_end));

    RMSE_V_cell_percentage_Reigon_4 = mean(abs(V_cell_estimate(Reigon_4_start:Reigon_4_end) - V_cell_truth_comparison_vector(Reigon_4_start:Reigon_4_end))./V_cell_truth_comparison_vector(Reigon_4_start:Reigon_4_end));

    RMSE_V_cell_percentage_Reigon_5 = mean(abs(V_cell_estimate(Reigon_5_start:Reigon_5_end) - V_cell_truth_comparison_vector(Reigon_5_start:Reigon_5_end))./V_cell_truth_comparison_vector(Reigon_5_start:Reigon_5_end));

    RMSE_V_cell_percentage_Reigon_6 = mean(abs(V_cell_estimate(Reigon_6_start:Reigon_6_end) - V_cell_truth_comparison_vector(Reigon_6_start:Reigon_6_end))./V_cell_truth_comparison_vector(Reigon_6_start:Reigon_6_end));

    RMSE_initial_V_cell = abs(V_cell_estimate(1) - V_cell_truth_comparison_vector(1))./V_cell_truth_comparison_vector(1) ;

    RMSE_end_V_cell = abs(V_cell_estimate(end) - V_cell_truth_comparison_vector(end))./V_cell_truth_comparison_vector(end) ;

    X_all_errors_reference = [RMSE_initial_V_cell; RMSE_V_cell_percentage_Reigon_1;RMSE_V_cell_percentage_Reigon_2;RMSE_V_cell_percentage_Reigon_3; RMSE_V_cell_percentage_Reigon_4;...
        RMSE_V_cell_percentage_Reigon_5; RMSE_V_cell_percentage_Reigon_6;RMSE_V_cell_percentage; RMSE_end_V_cell];

    %X_error_reference =mean(X_all_errors_reference);
    
    X_error_reference = mean(X_all_errors_reference(2:7));

    X_all_errors_output = X_all_errors_reference;
    X_errors_output = X_error_reference;
    %% Initialize algorithm
    %best = global_best_parameters;
    if err_con ==0
        best_eval = X_error_reference;
    else
        best_eval = X_all_errors_reference(1+err_con,1);
    end
    best_values = zeros(1,iter_max+1);
    best_values(1) = best_eval;
    temp_init = 50;
    step_size = 0.1;
    temp = zeros(1,iter_max+1);
    temp(1) = temp_init;
    curr_parameters = initial_parameter_set;
    global_best_parameters = initial_parameter_set;
    curr_eval = best_eval;
    n_parameters = length(global_best_parameters);
    %step_size_vector = delta_p.*global_best_parameters;




    %% Main Simulated Annealing Loop
    j =1;
    for i = 1:iter_max

        valid = 0;

        while(valid == 0)
            %% Generate Randomn Particle Around Current OP and Evaluate
            %%% Generate next point randomnly around current OP
            step_size_vector = delta_p.*global_best_parameters;

            candidate_parameters = curr_parameters + randn(n_parameters,1).*step_size_vector;
    
            %%% eps_neg and eps_pos based on eps_neg_elec and eps_pos_elec
            candidate_parameters(11,1) = 1 - candidate_parameters(10,1);
    
            candidate_parameters(20,1) = 1 - candidate_parameters(19,1);
    
            %%% Evaluate candidate
    
            %% check if particle is valid
        
    
            [V_cell,Flag_convergence,time_vector] = P2D_function(candidate_parameters,N_tot,N_shell,order,param,sim_type,V_cut_off_low,V_cut_off_high,capacity_cut_off,time_step,C_rate);

            if Flag_convergence ~= 0
    
                V_cell = V_cell(1)*ones(1,length(time_truth_comparison_vector));
                
                time_vector = time_truth_comparison_vector;
            end
    
            V_cell_estimate = pchip(time_vector,V_cell,time_truth_comparison_vector);
    
            RMSE_V_cell_percentage = mean(abs(V_cell_estimate - V_cell_truth_comparison_vector)./V_cell_truth_comparison_vector);
        
            RMSE_V_cell_percentage_Reigon_1 = mean(abs(V_cell_estimate(Reigon_1_start:Reigon_1_end) - V_cell_truth_comparison_vector(Reigon_1_start:Reigon_1_end))./V_cell_truth_comparison_vector(Reigon_1_start:Reigon_1_end));
        
            RMSE_V_cell_percentage_Reigon_2 = mean(abs(V_cell_estimate(Reigon_2_start:Reigon_2_end) - V_cell_truth_comparison_vector(Reigon_2_start:Reigon_2_end))./V_cell_truth_comparison_vector(Reigon_2_start:Reigon_2_end));
        
            RMSE_V_cell_percentage_Reigon_3 = mean(abs(V_cell_estimate(Reigon_3_start:Reigon_3_end) - V_cell_truth_comparison_vector(Reigon_3_start:Reigon_3_end))./V_cell_truth_comparison_vector(Reigon_3_start:Reigon_3_end));
        
            RMSE_V_cell_percentage_Reigon_4 = mean(abs(V_cell_estimate(Reigon_4_start:Reigon_4_end) - V_cell_truth_comparison_vector(Reigon_4_start:Reigon_4_end))./V_cell_truth_comparison_vector(Reigon_4_start:Reigon_4_end));
        
            RMSE_V_cell_percentage_Reigon_5 = mean(abs(V_cell_estimate(Reigon_5_start:Reigon_5_end) - V_cell_truth_comparison_vector(Reigon_5_start:Reigon_5_end))./V_cell_truth_comparison_vector(Reigon_5_start:Reigon_5_end));
        
            RMSE_V_cell_percentage_Reigon_6 = mean(abs(V_cell_estimate(Reigon_6_start:Reigon_6_end) - V_cell_truth_comparison_vector(Reigon_6_start:Reigon_6_end))./V_cell_truth_comparison_vector(Reigon_6_start:Reigon_6_end));
        
            RMSE_initial_V_cell = abs(V_cell_estimate(1) - V_cell_truth_comparison_vector(1))./V_cell_truth_comparison_vector(1) ;
        
            RMSE_end_V_cell = abs(V_cell_estimate(end) - V_cell_truth_comparison_vector(end))./V_cell_truth_comparison_vector(end) ;
    
            X_all_errors_next = [RMSE_initial_V_cell; RMSE_V_cell_percentage_Reigon_1;RMSE_V_cell_percentage_Reigon_2;RMSE_V_cell_percentage_Reigon_3; RMSE_V_cell_percentage_Reigon_4;...
            RMSE_V_cell_percentage_Reigon_5; RMSE_V_cell_percentage_Reigon_6;RMSE_V_cell_percentage; RMSE_end_V_cell];
    
            X_errors_next =mean(X_all_errors_next(2:7));
    
            if and(all([lt(X_all_errors_next(2,1),tol_count) lt(X_all_errors_next(3,1),tol_count) lt(X_all_errors_next(4,1),tol_count) lt(X_all_errors_next(5,1),tol_count) lt(X_all_errors_next(6,1),tol_count) lt(X_all_errors_next(7,1),tol_count)]),eq(Flag_convergence,0))
    
    
                valid = 1;
    
                
            end

            %% Check if search has found a better solution
            if err_con == 0
                candidate_eval = X_errors_next;
    
            end
    
            if err_con ~= 0              
    
                candidate_eval = X_all_errors_next(1+err_con,1);
         
            end

            

        end


        %% Condition for updating new best solution

            if candidate_eval < best_eval
                
                global_best_parameters = candidate_parameters;
                best_eval = candidate_eval;
                best_values(j+1) = best_eval;
                X_all_errors_output = X_all_errors_next;
                X_errors_output = X_errors_next;
        
                j = j+1;

            end


        %% Calculate difference between candidate and current point evaluation

        diff = candidate_eval - curr_eval;

        %% Calculate current temperature
        temp(i+1) = temp_init/(i+1);

        %% Calculate metropolis criterion

        metro = exp(-diff./temp(i+1));

        %%% Condition to update current point
        if or(diff<0,rand(1,1) < metro) == 1
        
            curr_parameters = candidate_parameters;
            curr_eval = candidate_eval;


        end

        %% Stop Condition
        if best_eval < tol_lim
            
            break;
    
        end

    end


    Output_parameter_set = global_best_parameters;


end