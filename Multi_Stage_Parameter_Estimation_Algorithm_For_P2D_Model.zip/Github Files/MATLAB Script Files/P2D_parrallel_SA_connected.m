%% Create Storage Variables
X_all_errors = zeros(6,n_operating_sets);
X_errors = zeros(1,n_operating_sets);
X_particles_output = zeros(n_parameters,n_operating_sets);
ouput_sets = 0;


%% Calculate Initial Performance
for i = 1:n_operating_sets

    Parameter_set_to_optimise =  Parameter_sets_to_optimise(:,i); 

    [V_cell,Flag_convergence,time_vector] = P2D_function(Parameter_set_to_optimise,N_tot,N_shell,order,param,sim_type,V_cut_off_low,V_cut_off_high,capacity_cut_off,time_step,C_rate);
    
    
    V_cell_estimate = pchip(time_vector,V_cell,time_truth_comparison_vector);
    
    RMSE_V_cell_percentage = mean(abs(V_cell_estimate - V_cell_truth_comparison_vector)./V_cell_truth_comparison_vector);
    
    RMSE_V_cell_percentage_Reigon_1 = mean(abs(V_cell_estimate(Reigon_1_start:Reigon_1_end) - V_cell_truth_comparison_vector(Reigon_1_start:Reigon_1_end))./V_cell_truth_comparison_vector(Reigon_1_start:Reigon_1_end));
    
    RMSE_V_cell_percentage_Reigon_2 = mean(abs(V_cell_estimate(Reigon_2_start:Reigon_2_end) - V_cell_truth_comparison_vector(Reigon_2_start:Reigon_2_end))./V_cell_truth_comparison_vector(Reigon_2_start:Reigon_2_end));
    
    RMSE_V_cell_percentage_Reigon_3 = mean(abs(V_cell_estimate(Reigon_3_start:Reigon_3_end) - V_cell_truth_comparison_vector(Reigon_3_start:Reigon_3_end))./V_cell_truth_comparison_vector(Reigon_3_start:Reigon_3_end));
    
    RMSE_V_cell_percentage_Reigon_4 = mean(abs(V_cell_estimate(Reigon_4_start:Reigon_4_end) - V_cell_truth_comparison_vector(Reigon_4_start:Reigon_4_end))./V_cell_truth_comparison_vector(Reigon_4_start:Reigon_4_end));
    
    RMSE_V_cell_percentage_Reigon_5 = mean(abs(V_cell_estimate(Reigon_5_start:Reigon_5_end) - V_cell_truth_comparison_vector(Reigon_5_start:Reigon_5_end))./V_cell_truth_comparison_vector(Reigon_5_start:Reigon_5_end));
    
    RMSE_V_cell_percentage_Reigon_6 = mean(abs(V_cell_estimate(Reigon_6_start:Reigon_6_end) - V_cell_truth_comparison_vector(Reigon_6_start:Reigon_6_end))./V_cell_truth_comparison_vector(Reigon_6_start:Reigon_6_end));
    
    RMSE_initial_V_cell = abs(V_cell_estimate(1) - V_cell_truth_comparison_vector(1))./V_cell_truth_comparison_vector(1) ;
    
    RMSE_end_V_cell = abs(V_cell_estimate(end) - V_cell_truth_comparison_vector(end))./V_cell_truth_comparison_vector(end) ;
    
    
    X_all_errors(:,i) = [RMSE_V_cell_percentage_Reigon_1;RMSE_V_cell_percentage_Reigon_2;RMSE_V_cell_percentage_Reigon_3; RMSE_V_cell_percentage_Reigon_4;...
                RMSE_V_cell_percentage_Reigon_5; RMSE_V_cell_percentage_Reigon_6];
        
    X_errors(i) =mean(X_all_errors(:,i));

end

%% Initialise SA Algorithm
loop_count = 1;
delta_p = delta_p*ones(n_parameters,1);
Parameters_sets = zeros(loop_max+1,n_parameters,n_operating_sets);
Parameters_sets(loop_count,:,:) = Parameter_sets_to_optimise;
n_operating_sets_temp = n_operating_sets;
%% Run SA Loop

while and(mean(X_errors)> tol_lim,ouput_sets<n_operating_sets)
    for i = 1:n_operating_sets_temp
    
    Parameter_set_to_optimise =  Parameter_sets_to_optimise(:,i);
    
    err_con =  0;
    
    
    [Output_parameter_set, X_all_errors_output, X_errors_output] = P2D_Simulated_Annealing(Parameter_set_to_optimise,V_cell_truth_comparison_vector,Reigon_indexes,tol_count,tol_lim,time_truth_comparison_vector, delta_p,iter_max,err_con,Comparison_points,N_tot,N_shell,order,param,sim_type,V_cut_off_low,V_cut_off_high,capacity_cut_off,time_step,C_rate);
    
    
    Parameters_sets(loop_count+1,:,i) = Output_parameter_set';

    Parameter_sets_to_optimise(:,i) = Output_parameter_set;

    output_Reigon_Errors = ['Parameter Set ',num2str(i),' Results for Iteration count = ',num2str(loop_count),', Reigon 1 Error = ',num2str(X_all_errors_output(2)),', Reigon 2 Error = ',num2str(X_all_errors_output(3)), ', Reigon 3 Error = ',num2str(X_all_errors_output(4))...
           ', Reigon 4 Error = ',num2str(X_all_errors_output(5)), ', Reigon 5 Error = ',num2str(X_all_errors_output(6)),', Reigon 6 Error = ',num2str(X_all_errors_output(7)), ', Mean Error = ', num2str(X_errors_output)];
    disp(output_Reigon_Errors);

    
    [V_cell,Flag_convergence,time_vector] = P2D_function(Output_parameter_set,N_tot,N_shell,order,param,sim_type,V_cut_off_low,V_cut_off_high,capacity_cut_off,time_step,C_rate);
    
        
    
    V_cell_estimate = pchip(time_vector,V_cell,time_truth_comparison_vector);
    
    RMSE_V_cell_percentage = mean(abs(V_cell_estimate - V_cell_truth_comparison_vector)./V_cell_truth_comparison_vector);
    
    RMSE_V_cell_percentage_Reigon_1 = mean(abs(V_cell_estimate(Reigon_1_start:Reigon_1_end) - V_cell_truth_comparison_vector(Reigon_1_start:Reigon_1_end))./V_cell_truth_comparison_vector(Reigon_1_start:Reigon_1_end));
    
    RMSE_V_cell_percentage_Reigon_2 = mean(abs(V_cell_estimate(Reigon_2_start:Reigon_2_end) - V_cell_truth_comparison_vector(Reigon_2_start:Reigon_2_end))./V_cell_truth_comparison_vector(Reigon_2_start:Reigon_2_end));
    
    RMSE_V_cell_percentage_Reigon_3 = mean(abs(V_cell_estimate(Reigon_3_start:Reigon_3_end) - V_cell_truth_comparison_vector(Reigon_3_start:Reigon_3_end))./V_cell_truth_comparison_vector(Reigon_3_start:Reigon_3_end));
    
    RMSE_V_cell_percentage_Reigon_4 = mean(abs(V_cell_estimate(Reigon_4_start:Reigon_4_end) - V_cell_truth_comparison_vector(Reigon_4_start:Reigon_4_end))./V_cell_truth_comparison_vector(Reigon_4_start:Reigon_4_end));
    
    RMSE_V_cell_percentage_Reigon_5 = mean(abs(V_cell_estimate(Reigon_5_start:Reigon_5_end) - V_cell_truth_comparison_vector(Reigon_5_start:Reigon_5_end))./V_cell_truth_comparison_vector(Reigon_5_start:Reigon_5_end));
    
    RMSE_V_cell_percentage_Reigon_6 = mean(abs(V_cell_estimate(Reigon_6_start:Reigon_6_end) - V_cell_truth_comparison_vector(Reigon_6_start:Reigon_6_end))./V_cell_truth_comparison_vector(Reigon_6_start:Reigon_6_end));
    
    RMSE_initial_V_cell = abs(V_cell_estimate(1) - V_cell_truth_comparison_vector(1))./V_cell_truth_comparison_vector(1) ;
    
    RMSE_end_V_cell = abs(V_cell_estimate(end) - V_cell_truth_comparison_vector(end))./V_cell_truth_comparison_vector(end) ;
    
    X_all_errors_reference = [RMSE_V_cell_percentage_Reigon_1;RMSE_V_cell_percentage_Reigon_2;RMSE_V_cell_percentage_Reigon_3; RMSE_V_cell_percentage_Reigon_4;...
        RMSE_V_cell_percentage_Reigon_5; RMSE_V_cell_percentage_Reigon_6];

    X_all_errors(:,i) = X_all_errors_reference;
    
    X_error_reference =mean(X_all_errors_reference);

    X_errors(i) = X_error_reference;




    end
    
    loop_count = loop_count + 1;

    %% Push Out Optimised Parameter Sets
    output_Reigon_Errors = [num2str(loop_count),' Iterations Complete, Remaining P_{set} Mean Error = ', num2str(mean(X_errors))];
    disp(output_Reigon_Errors);
    stop_check = sum(lt(X_errors,tol_lim));
    
    if stop_check > 0
        out_idx = find(lt(X_errors,tol_lim));

        for m = 1:length(out_idx)
            
            X_particles_output(:,ouput_sets+m) = Parameter_sets_to_optimise(:,out_idx(m));

            
        end
        

        %% Concacnate Parameter sets

        Parameter_sets_to_optimise(:,out_idx) = [];
        
        X_errors(out_idx) = [];

        n_operating_sets_temp = size(Parameter_sets_to_optimise,2);

        ouput_sets = ouput_sets + length(out_idx);

        output_Reigon_Errors = ['Number of optimised parameter sets  = ',num2str(ouput_sets)];
        disp(output_Reigon_Errors);
    end

end


%% Write Out Parameter Set Outputs


writematrix([X_particles_output],'Stage_2_connected_output_sets.txt','Delimiter',' ');