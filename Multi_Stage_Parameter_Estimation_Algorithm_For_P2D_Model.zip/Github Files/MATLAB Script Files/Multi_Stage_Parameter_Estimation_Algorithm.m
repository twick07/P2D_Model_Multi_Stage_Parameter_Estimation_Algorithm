clear;
close all;

%% Script for P2D model multi-stage stochastic optimisation algorithm

%% Select Stage
%%% stage_x = 1  for PSO
%%% stage_x = 2  for SA
stage_1 = 1;
stage_2 = 2;

%% Alogrithm Parameters
Comparison_points = 1000; %% Length of Voltage time-series vectors
time_step = 1;
order = 5; %% Setting for radial integration in P2D function
N_tot = 30; %% Mesh size in x
N_shell = 5; %% Mesh size in r
V_cut_off_low = 2.8; %% Low voltage cut-off for discharge
V_cut_off_high = 4.15; %% High voltage cut-off for charge
capacity_cut_off = 0.1; %% Lowest capacity allowed in electrode
n_parameters = 26; %% Parameter size, (Only 23 of the 26 are varied)
n_operating_sets = 3; %% Number of Parameter Sets Being Output

%% Model Selection
param  =1; %% param = 1 for LCO, param = 2 for NMC
sim_type = 3; %% sim_type = 1 for discharge, sim_type =2 for charge, sim_type =3 discharge/charge
C_rate = 1; %% Discharge current



%% Import Reference Data

%%% LCO Simulation Data
if (param == 1)

    A = readmatrix('P2D_LCO_Reference_Voltage.txt');

end

%%% NMC Simulation Data
if (param == 2)

    A = readmatrix('P2D_NMC_Reference_Voltage.txt');

end



time_truth = A(:,1)';
Voltage_truth = A(:,2);

time_truth_comparison_vector = linspace(0,time_truth(end),Comparison_points);
V_cell_truth_comparison_vector = pchip(time_truth,Voltage_truth,time_truth_comparison_vector);

%%% Reigon Indexing
Reigon_1_start = 1;
Reigon_1_end = round((1/6)*length(time_truth_comparison_vector));
Reigon_2_start = Reigon_1_end+1;
Reigon_2_end = round((2/6)*length(time_truth_comparison_vector));
Reigon_3_start = Reigon_2_end+1;
Reigon_3_end = round((3/6)*length(time_truth_comparison_vector));
Reigon_4_start = Reigon_3_end+1;
Reigon_4_end = round((4/6)*length(time_truth_comparison_vector));
Reigon_5_start = Reigon_4_end+1;
Reigon_5_end = round((5/6)*length(time_truth_comparison_vector));
Reigon_6_start = Reigon_5_end+1;
Reigon_6_end = length(time_truth_comparison_vector);
Reigon_indexes = [Reigon_1_start Reigon_1_end Reigon_2_start Reigon_2_end Reigon_3_start Reigon_3_end Reigon_4_start Reigon_4_end ...
    Reigon_5_start Reigon_5_end Reigon_6_start Reigon_6_end];


%% Parameter Boundaries 
parameter_boundaries = zeros(n_parameters,2);

parameter_boundaries(1,:) = [1e-4 2e-1]; %Boundaries for Cell Area
parameter_boundaries(2,:) = [1.0 5.0]; %Boundaries for bruggman coeffcient
parameter_boundaries(3,:) = [10e-6 50e-6]; %Boundaries for Length of Seperator
parameter_boundaries(4,:) = [500 1500]; %Boundaries for C_e_init
parameter_boundaries(5,:) = [5e-12 5e-8]; %Boundaries for D_elec                          
parameter_boundaries(6,:) = [0.2 0.5]; %Boundaries for t_li
parameter_boundaries(7,:) = [0.4 0.8]; %Boundaries for eps_sep_elec % Tuned
parameter_boundaries(8,:) = [50e-6 120e-6]; %Boundaries for L_neg
parameter_boundaries(9,:) = [0.6 0.99];%Boundaries for SoC_neg_init
parameter_boundaries(10,:) = [0.2 0.6]; %Boundaries for eps_neg_elec
parameter_boundaries(11,:) = [0.2 0.6]; %Boundaries for eps_neg
parameter_boundaries(12,:) = [25000 60000]; %Boundaries for C_max_neg % Tuned
parameter_boundaries(13,:) = [0.5e-6 10e-6]; %Boundaries for Rs_neg
parameter_boundaries(14,:) = [1e-15 1e-13]; %Boundaries for Ds_neg
parameter_boundaries(15,:) = [10 500]; %Boundaries for Sigma_neg
parameter_boundaries(16,:) = [5e-12 5e-10]; %Boundaries for ko_neg
parameter_boundaries(17,:) = [50e-6 120e-6]; %Boundaries for L_pos
parameter_boundaries(18,:) = [0.3 0.6]; %Boundaries for SoC_pos_init
parameter_boundaries(19,:) = [0.2 0.6]; %Boundaries for eps_pos_elec
parameter_boundaries(20,:) = [0.2 0.6]; %Boundaries for eps_pos
parameter_boundaries(21,:) = [25000 60000]; %Boundaries for C_max_pos % Tuned
parameter_boundaries(22,:) = [0.5e-6 10e-6]; %Boundaries for Rs_pos
parameter_boundaries(23,:) = [1e-15 1e-13]; %Boundaries for Ds_pos
parameter_boundaries(24,:) = [10 500]; %Boundaries for Sigma_pos
parameter_boundaries(25,:) = [5e-12 5e-10]; %Boundaries for ko_pos
parameter_boundaries(26,:) = [0.02 0.7]; %Boundaries for kappa %Tuned

log_parameter_indices = [1 3 5 8 13 14 16 17 22 23 25 26];
Index_to_optimise = linspace(1,n_parameters,n_parameters);



%% Run Stage 1 : PSO Estimation

%%% PSO Parameter Estimation %%%

if stage_1 == 1
    
    disp('Running Stage 1: Particle Swarm Algorithm');

    

    %% Set PSO Algorithm Hyperparameters
    c1 = 0.5;
    c2 = 0.1;
    w = 0.8;
    iter_max = 100;
    iter = 1;
    %n_particles = 12;
    n_particles = 15;
    tol_count_1 = 10e-2; %% Initial allowed error for first generation of PSO parameter sets
    tol_count_2 = 1.0e-2; %% PSO cut off error


    %% Run PSO Algorithm
    tic;
    P2D_PSO_connected;
    toc;
    
    disp('Stage 1 Completed');
end


%% Run Stage 2 : Simultaneous Simulated Annealing
%% Stage 2 SA simulation
if stage_2 == 2

    disp('Running Stage 2: Simulated Annealing Algorithm');
    %% Read previous stage best parameter set
    Parameter_sets_to_optimise = readmatrix('Stage_1_connected_output_sets.txt');

    %% Set SA Algorithm Hyperparameters
    tol_count = 4e-2; %% Setting for SA function, limit for a valid particle.
    tol_lim = 0.5e-2; %% Limit for SA valid particle
    delta_p = 0.01; %% Parameter search space variation around current parameter set
    iter_max = 6; %% SA loops per iteration
    loop_count = 1; %% Initialisation
    loop_max = 6; %% SA loops per iteration

    %% Run SA Algorithm
    tic;
    P2D_parrallel_SA_connected;
    toc;

    disp('Stage 2 Completed');
    



end



%% Run DST Validation

disp('Running Stage 3: Drive Cycle Validation');

%%% Import Previous Stage Output Parameter Sets %%%
Parameter_sets_to_optimise = readmatrix('Stage_2_connected_output_sets.txt');

%% Import Reference Data

%%% LCO Simulation Data
if (param == 1)

    A = readmatrix('P2D_LCO_Reference_Voltage_DST.txt');
    sim_type = 4;

end

%%% NMC Simulation Data
if (param == 2)

   A = readmatrix('P2D_NMC_Reference_Voltage_DST.txt');
   sim_type = 4;

end




time_truth = A(:,1)';
Voltage_truth = A(:,2);

time_truth_comparison_vector = linspace(0,time_truth(end),Comparison_points);
V_cell_truth_comparison_vector = pchip(time_truth,Voltage_truth,time_truth_comparison_vector);


%%% Run DST PSO for SoC_p and SoC_n %%%

n_particles = 4;
tol_count = 1e-2;
convergence_limit = 14;

tic;
P2D_DST_Validation;
toc;

disp('Stage 3 Completed');












