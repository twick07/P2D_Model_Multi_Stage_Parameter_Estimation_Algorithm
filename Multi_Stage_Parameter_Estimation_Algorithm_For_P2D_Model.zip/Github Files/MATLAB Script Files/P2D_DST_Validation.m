%% Run DST Validation For 3 Parameter Sets

%% DST Error Calculation
cadidate_set_errors = ones(1,n_operating_sets);
for k = 1:n_operating_sets
    
    Parameter_set_to_optimise = Parameter_sets_to_optimise(:,k);

    [V_cell,Flag_convergence,time_vector] = P2D_function(Parameter_set_to_optimise,N_tot,N_shell,order,param,sim_type,V_cut_off_low,V_cut_off_high,capacity_cut_off,time_step,C_rate);


    if Flag_convergence ~= 0
    
                V_cell = V_cell(1)*ones(1,length(time_truth_comparison_vector));
                
                time_vector = time_truth_comparison_vector;
    end

    V_cell_estimate = pchip(time_vector,V_cell,time_truth_comparison_vector);
    
    RMSE_V_cell_percentage = mean(abs(V_cell_estimate - V_cell_truth_comparison_vector)./V_cell_truth_comparison_vector);

    cadidate_set_errors(k) = RMSE_V_cell_percentage;
end


%% Post Processing
[b1 , i_1] = sort(cadidate_set_errors);

X_particles_output = Parameter_sets_to_optimise(:,i_1(1));

writematrix([X_particles_output],'Stage_3_connected_output_sets.txt','Delimiter',' ');
    
